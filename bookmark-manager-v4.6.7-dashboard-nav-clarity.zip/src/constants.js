export const MATCH_MODES = {
  PAGE: 'page',
  HOST: 'host',
  DOMAIN: 'domain'
};

export const SORT_OPTIONS = {
  TITLE_ASC: 'title-asc',
  URL_ASC: 'url-asc',
  NEWEST: 'newest',
  OLDEST: 'oldest',
  PATH_ASC: 'path-asc'
};

export const POPUP_WIDTHS = {
  COMPACT: 'compact',
  COMFORTABLE: 'comfortable'
};

export const THEME_MODES = {
  SYSTEM: 'system',
  LIGHT: 'light',
  DARK: 'dark'
};

export const MERGE_STRATEGIES = {
  KEEP_NEWEST: 'keep-newest',
  KEEP_OLDEST: 'keep-oldest'
};

export const CLEANUP_FILTERS = {
  ALL: 'all',
  DUPLICATES: 'duplicates',
  UNTITLED: 'untitled',
  OLD: 'old',
  TITLE_COLLISIONS: 'title-collisions'
};

export const OLD_BOOKMARK_DAYS = 730;

export const STORAGE_KEYS = {
  POPUP_MODE: 'popupMode',
  POPUP_SORT: 'popupSort',
  DUPLICATES_ONLY: 'duplicatesOnly',
  IGNORE_QUERY: 'ignoreQueryString',
  IGNORE_HASH: 'ignoreHashFragment',
  POPUP_WIDTH: 'popupWidth',
  MERGE_STRATEGY: 'mergeStrategy',
  CLEANUP_FILTER: 'cleanupFilter',
  REVIEW_SESSIONS: 'reviewSessions',
  CLEANUP_HISTORY: 'cleanupHistory',
  REVIEW_REMINDER_ENABLED: 'reviewReminderEnabled',
  REVIEW_REMINDER_INTERVAL_DAYS: 'reviewReminderIntervalDays',
  REVIEW_REMINDER_LAST_REVIEW_AT: 'reviewReminderLastReviewAt',
  REVIEW_REMINDER_NEXT_AT: 'reviewReminderNextAt',
  THEME_MODE: 'themeMode'
};

export const KEYBOARD_SHORTCUTS = {
  SEARCH: '/',
  MODE_PAGE: '1',
  MODE_HOST: '2',
  MODE_DOMAIN: '3'
};


export const HEALTH_STATUSES = {
  UNKNOWN: 'unknown',
  HEALTHY: 'healthy',
  REDIRECTED: 'redirected',
  BROKEN: 'broken',
  SERVER_ERROR: 'server-error',
  UNREACHABLE: 'unreachable'
};

export const HEALTH_SCAN_TIMEOUT_MS = 8000;
export const HEALTH_SCAN_CONCURRENCY = 4;
