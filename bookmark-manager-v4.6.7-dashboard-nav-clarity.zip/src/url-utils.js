const MULTI_PART_TLDS = new Set([
  'co.uk', 'org.uk', 'gov.uk', 'ac.uk',
  'com.au', 'net.au', 'org.au',
  'co.nz', 'org.nz',
  'co.jp',
  'com.br', 'com.mx',
  'co.in', 'firm.in', 'net.in', 'org.in'
]);

function normalizePathname(pathname) {
  if (!pathname || pathname === '/') {
    return '/';
  }
  const trimmed = pathname.replace(/\/+$/, '');
  return trimmed || '/';
}

function normalizeSearch(search, ignoreQueryString) {
  if (ignoreQueryString) return '';
  return search || '';
}

function normalizeHash(hash, ignoreHashFragment) {
  if (ignoreHashFragment) return '';
  return hash || '';
}

export function getRegistrableDomain(hostname) {
  const normalized = String(hostname || '').toLowerCase().trim();
  if (!normalized) return '';
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(normalized) || normalized === 'localhost') {
    return normalized;
  }

  const parts = normalized.split('.').filter(Boolean);
  if (parts.length <= 2) return normalized;

  const lastTwo = parts.slice(-2).join('.');
  if (MULTI_PART_TLDS.has(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join('.');
  }

  return parts.slice(-2).join('.');
}

export function parseUrlSafe(rawUrl, options = {}) {
  const {
    ignoreQueryString = false,
    ignoreHashFragment = true
  } = options;

  try {
    const url = new URL(rawUrl);
    if (!['http:', 'https:'].includes(url.protocol)) {
      return { valid: false, reason: 'unsupported_scheme', rawUrl };
    }

    const hostname = url.hostname.toLowerCase();
    const pathname = normalizePathname(url.pathname);
    const search = normalizeSearch(url.search, ignoreQueryString);
    const hash = normalizeHash(url.hash, ignoreHashFragment);

    return {
      valid: true,
      rawUrl,
      protocol: url.protocol,
      hostname,
      domain: getRegistrableDomain(hostname),
      pathname,
      search,
      hash,
      normalizedPageKey: `${url.protocol}//${hostname}${pathname}${search}${hash}`,
      displayUrl: `${url.protocol}//${hostname}${pathname}${url.search || ''}${url.hash || ''}`
    };
  } catch {
    return { valid: false, reason: 'invalid_url', rawUrl };
  }
}

export function getMatchTarget(tabUrl, options = {}) {
  const parsed = parseUrlSafe(tabUrl, options);
  if (!parsed.valid) {
    return {
      valid: false,
      label: 'Unsupported page',
      subtitle: 'Open an http or https page to inspect related bookmarks.'
    };
  }

  return {
    valid: true,
    ...parsed,
    label: parsed.displayUrl,
    subtitle: `${parsed.hostname} · ${parsed.domain}`
  };
}

export function matchesMode(bookmarkMeta, target, mode) {
  if (!bookmarkMeta.parsed.valid || !target.valid) return false;

  switch (mode) {
    case 'page':
      return bookmarkMeta.parsed.normalizedPageKey === target.normalizedPageKey;
    case 'host':
      return bookmarkMeta.parsed.hostname === target.hostname;
    case 'domain':
      return bookmarkMeta.parsed.domain === target.domain;
    default:
      return false;
  }
}
