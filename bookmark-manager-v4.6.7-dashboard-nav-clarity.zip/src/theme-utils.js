import { STORAGE_KEYS, THEME_MODES } from './constants.js';

export function resolveThemeMode(mode = THEME_MODES.SYSTEM) {
  if (mode === THEME_MODES.LIGHT) return THEME_MODES.LIGHT;
  if (mode === THEME_MODES.DARK) return THEME_MODES.DARK;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? THEME_MODES.DARK : THEME_MODES.LIGHT;
}

export function applyTheme(mode = THEME_MODES.SYSTEM) {
  const resolved = resolveThemeMode(mode);
  document.documentElement.dataset.themeMode = mode;
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
  return resolved;
}

export async function loadStoredTheme() {
  const stored = await chrome.storage.local.get([STORAGE_KEYS.THEME_MODE]);
  return stored[STORAGE_KEYS.THEME_MODE] || THEME_MODES.SYSTEM;
}

export async function saveThemeMode(mode) {
  await chrome.storage.local.set({ [STORAGE_KEYS.THEME_MODE]: mode });
  return applyTheme(mode);
}

export function watchSystemTheme(onChange) {
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  const handler = () => onChange(media.matches ? THEME_MODES.DARK : THEME_MODES.LIGHT);
  if (typeof media.addEventListener === 'function') media.addEventListener('change', handler);
  else media.addListener(handler);
  return () => {
    if (typeof media.removeEventListener === 'function') media.removeEventListener('change', handler);
    else media.removeListener(handler);
  };
}
