import { matchesMode, parseUrlSafe } from './url-utils.js';
import { CLEANUP_FILTERS, OLD_BOOKMARK_DAYS } from './constants.js';

function flattenNodes(nodes, pathParts = [], out = [], parseOptions = {}) {
  for (const node of nodes || []) {
    if (node.url) {
      out.push({
        id: node.id,
        parentId: node.parentId || '',
        index: Number.isInteger(node.index) ? node.index : 0,
        title: node.title || '(Untitled bookmark)',
        url: node.url,
        dateAdded: node.dateAdded || 0,
        path: pathParts.join(' / ') || 'Root',
        parsed: parseUrlSafe(node.url, parseOptions)
      });
      continue;
    }

    const nextPath = node.title ? [...pathParts, node.title] : pathParts;
    if (Array.isArray(node.children) && node.children.length) {
      flattenNodes(node.children, nextPath, out, parseOptions);
    }
  }
}

export async function getNormalizedBookmarks(parseOptions = {}) {
  const tree = await chrome.bookmarks.getTree();
  const output = [];
  flattenNodes(tree, [], output, parseOptions);
  return output;
}

export async function getDefaultImportParentId() {
  const tree = await chrome.bookmarks.getTree();
  const root = tree?.[0];
  const children = root?.children || [];
  const other = children.find((node) => String(node.id) === '2' || /other bookmarks/i.test(node.title || ''));
  const bar = children.find((node) => String(node.id) === '1' || /bookmarks bar/i.test(node.title || ''));
  return other?.id || bar?.id || children?.[0]?.id || root?.id || undefined;
}

function normalizeTitle(title) {
  return String(title || '').trim().toLowerCase();
}

function isEffectivelyUntitled(title) {
  const normalized = normalizeTitle(title);
  return !normalized || normalized === '(untitled bookmark)' || normalized === 'untitled' || normalized === 'new bookmark';
}

export function detectDuplicates(bookmarks) {
  const urlCounts = new Map();
  const titleToUrls = new Map();
  const now = Date.now();

  for (const bookmark of bookmarks) {
    const urlKey = bookmark.parsed.valid ? bookmark.parsed.normalizedPageKey : bookmark.url;
    const titleKey = normalizeTitle(bookmark.title);
    urlCounts.set(urlKey, (urlCounts.get(urlKey) || 0) + 1);
    if (titleKey) {
      const set = titleToUrls.get(titleKey) || new Set();
      set.add(urlKey);
      titleToUrls.set(titleKey, set);
    }
  }

  return bookmarks.map((bookmark) => {
    const urlKey = bookmark.parsed.valid ? bookmark.parsed.normalizedPageKey : bookmark.url;
    const titleKey = normalizeTitle(bookmark.title);
    const ageDays = bookmark.dateAdded ? Math.floor((now - bookmark.dateAdded) / 86400000) : null;
    const titleUrlSet = titleToUrls.get(titleKey);
    const titleCollisionCount = titleUrlSet ? titleUrlSet.size : 0;
    return {
      ...bookmark,
      duplicateKey: urlKey,
      isDuplicate: (urlCounts.get(urlKey) || 0) > 1,
      isUntitled: isEffectivelyUntitled(bookmark.title),
      ageDays,
      isOld: Number.isFinite(ageDays) ? ageDays >= OLD_BOOKMARK_DAYS : false,
      hasTitleCollision: Boolean(titleKey) && titleCollisionCount > 1,
      titleCollisionCount
    };
  });
}

const parsedSearchCache = new Map();

function parseSearchQuery(rawQuery) {
  const query = String(rawQuery || '').trim();
  const cacheKey = query.toLowerCase();
  if (parsedSearchCache.has(cacheKey)) return parsedSearchCache.get(cacheKey);
  const tokens = query ? query.split(/\s+/) : [];
  const terms = [];
  const ops = {
    title: [],
    url: [],
    path: [],
    host: [],
    domain: [],
    health: [],
    flags: new Set()
  };

  for (const token of tokens) {
    const match = token.match(/^(title|url|path|host|domain|is|age):(.*)$/i);
    if (!match) {
      terms.push(token.toLowerCase());
      continue;
    }
    const key = match[1].toLowerCase();
    const value = match[2].trim().toLowerCase();
    if (!value) continue;
    if (key === 'is') {
      ops.flags.add(value);
    } else if (key === 'age') {
      if (value === 'old' || value === 'stale') ops.flags.add('old');
    } else if (key === 'health') {
      ops.health.push(value);
    } else {
      ops[key].push(value);
    }
  }

  const parsed = { terms, ops };
  if (parsedSearchCache.size > 100) {
    const firstKey = parsedSearchCache.keys().next().value;
    if (firstKey !== undefined) parsedSearchCache.delete(firstKey);
  }
  parsedSearchCache.set(cacheKey, parsed);
  return parsed;
}

function matchesAdvancedSearch(bookmark, parsedQuery) {
  const { terms, ops } = parsedQuery;
  const title = String(bookmark.title || '').toLowerCase();
  const url = String(bookmark.url || '').toLowerCase();
  const path = String(bookmark.path || '').toLowerCase();
  const host = String(bookmark.parsed?.hostname || '').toLowerCase();
  const domain = String(bookmark.parsed?.domain || '').toLowerCase();
  const composite = `${title} ${url} ${path}`;

  if (terms.some((term) => !composite.includes(term))) return false;
  if (ops.title.some((term) => !title.includes(term))) return false;
  if (ops.url.some((term) => !url.includes(term))) return false;
  if (ops.path.some((term) => !path.includes(term))) return false;
  if (ops.host.some((term) => !host.includes(term))) return false;
  if (ops.domain.some((term) => !domain.includes(term))) return false;

  if (ops.health.length) {
    const bookmarkHealth = String(bookmark.healthStatus || '').toLowerCase();
    const isBad = ['broken', 'server-error', 'unreachable'].includes(bookmarkHealth);
    const isGood = ['healthy', 'redirected'].includes(bookmarkHealth);
    for (const term of ops.health) {
      if (term === 'bad' && !isBad) return false;
      if ((term === 'good' || term === 'ok') && !isGood) return false;
      if (term !== 'bad' && term !== 'good' && term !== 'ok' && bookmarkHealth !== term) return false;
    }
  }

  if (ops.flags.has('duplicate') && !bookmark.isDuplicate) return false;
  if (ops.flags.has('untitled') && !bookmark.isUntitled) return false;
  if (ops.flags.has('old') && !bookmark.isOld) return false;
  if ((ops.flags.has('collision') || ops.flags.has('title-collision')) && !bookmark.hasTitleCollision) return false;

  return true;
}

function matchesCleanupFilter(bookmark, cleanupFilter) {
  switch (cleanupFilter) {
    case CLEANUP_FILTERS.DUPLICATES:
      return bookmark.isDuplicate;
    case CLEANUP_FILTERS.UNTITLED:
      return bookmark.isUntitled;
    case CLEANUP_FILTERS.OLD:
      return bookmark.isOld;
    case CLEANUP_FILTERS.TITLE_COLLISIONS:
      return bookmark.hasTitleCollision;
    case CLEANUP_FILTERS.ALL:
    default:
      return true;
  }
}

export function filterBookmarks(bookmarks, target, mode, query, options = {}) {
  const {
    duplicatesOnly = false,
    cleanupFilter = CLEANUP_FILTERS.ALL
  } = options;

  const parsedQuery = parseSearchQuery(query);

  return bookmarks.filter((bookmark) => {
    if (!matchesMode(bookmark, target, mode)) return false;
    if (duplicatesOnly && !bookmark.isDuplicate) return false;
    if (!matchesCleanupFilter(bookmark, cleanupFilter)) return false;
    return matchesAdvancedSearch(bookmark, parsedQuery);
  });
}

export function filterScopedBookmarks(bookmarks, query, options = {}) {
  const {
    duplicatesOnly = false,
    cleanupFilter = CLEANUP_FILTERS.ALL
  } = options;
  const parsedQuery = parseSearchQuery(query);

  return bookmarks.filter((bookmark) => {
    if (duplicatesOnly && !bookmark.isDuplicate) return false;
    if (!matchesCleanupFilter(bookmark, cleanupFilter)) return false;
    return matchesAdvancedSearch(bookmark, parsedQuery);
  });
}

export function sortBookmarks(bookmarks, sortValue) {
  const items = [...bookmarks];
  items.sort((a, b) => {
    switch (sortValue) {
      case 'url-asc':
        return a.url.localeCompare(b.url, undefined, { sensitivity: 'base' });
      case 'newest':
        return (b.dateAdded || 0) - (a.dateAdded || 0);
      case 'oldest':
        return (a.dateAdded || 0) - (b.dateAdded || 0);
      case 'path-asc':
        return (a.path || '').localeCompare(b.path || '', undefined, { sensitivity: 'base' });
      case 'title-asc':
      default:
        return a.title.localeCompare(b.title, undefined, { sensitivity: 'base' });
    }
  });
  return items;
}

export function groupDuplicates(bookmarks) {
  const groups = new Map();
  for (const bookmark of bookmarks) {
    if (!bookmark.isDuplicate) continue;
    const key = bookmark.duplicateKey;
    const list = groups.get(key) || [];
    list.push(bookmark);
    groups.set(key, list);
  }
  return groups;
}

export function getCleanupSummary(bookmarks) {
  return {
    total: bookmarks.length,
    duplicateCount: bookmarks.filter((bookmark) => bookmark.isDuplicate).length,
    untitledCount: bookmarks.filter((bookmark) => bookmark.isUntitled).length,
    oldCount: bookmarks.filter((bookmark) => bookmark.isOld).length,
    titleCollisionCount: bookmarks.filter((bookmark) => bookmark.hasTitleCollision).length,
    duplicateGroupCount: groupDuplicates(bookmarks).size
  };
}
